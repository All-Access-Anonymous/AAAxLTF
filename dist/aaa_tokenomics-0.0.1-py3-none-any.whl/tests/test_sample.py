"""
Test file, mostly to confirm we have properly
configured the Python Poetry workflow, and setup
the Poetry script for local testing
"""

import pytest

def test_func():
    assert 4 + 1 == 5
